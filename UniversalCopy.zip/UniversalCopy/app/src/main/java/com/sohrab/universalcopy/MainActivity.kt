package com.sohrab.universalcopy

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (24 * resources.displayMetrics.density).toInt()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(pad, pad, pad, pad)
        }
        val info = TextView(this).apply {
            textSize = 17f
            text = "Universal Copy চালু করার নিয়ম:\n\n" +
                "১. নিচের বাটনে চাপুন\n" +
                "২. Installed apps (বা Downloaded apps) এ Universal Copy খুঁজে চাপুন\n" +
                "৩. সার্ভিস ON করুন\n" +
                "৪. যেকোনো অ্যাপে গিয়ে ভাসমান কপি বাটনে চাপুন\n" +
                "৫. যে লেখা কপি করতে চান টিক দিন, তারপর \"কপি\" চাপুন"
        }
        val btn = Button(this).apply {
            text = "Accessibility সেটিংস খুলুন"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        layout.addView(info)
        layout.addView(btn)
        setContentView(layout)
    }
}
