package com.sohrab.universalcopy

import android.accessibilityservice.AccessibilityService
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

class UniversalCopyService : AccessibilityService() {

    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var panel: View? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        showBubble()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        closePanel()
        bubble?.let { runCatching { wm.removeView(it) } }
        bubble = null
        super.onDestroy()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun overlayParams(w: Int, h: Int) = WindowManager.LayoutParams(
        w, h,
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
        PixelFormat.TRANSLUCENT
    )

    // ---------- ভাসমান বাটন ----------
    private fun showBubble() {
        if (bubble != null) return
        val size = dp(52)
        val v = TextView(this).apply {
            text = "কপি"
            setTextColor(Color.WHITE)
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xFF6200EE.toInt())
            }
            alpha = 0.9f
        }
        val lp = overlayParams(size, size).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = resources.displayMetrics.heightPixels / 3
        }
        var startX = 0; var startY = 0; var touchX = 0f; var touchY = 0f; var moved = false
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x; startY = lp.y
                    touchX = e.rawX; touchY = e.rawY; moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - touchX).toInt()
                    val dy = (e.rawY - touchY).toInt()
                    if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                    if (moved) {
                        lp.x = startX + dx; lp.y = startY + dy
                        wm.updateViewLayout(v, lp)
                    }
                }
                MotionEvent.ACTION_UP -> if (!moved) onBubbleTap()
            }
            true
        }
        wm.addView(v, lp)
        bubble = v
    }

    private fun onBubbleTap() {
        if (panel != null) { closePanel(); return }
        val texts = LinkedHashSet<String>()
        collect(rootInActiveWindow, texts)
        if (texts.isEmpty()) {
            Toast.makeText(this, "এই স্ক্রিনে কোনো লেখা পাওয়া যায়নি", Toast.LENGTH_SHORT).show()
            return
        }
        showPanel(texts.toList())
    }

    // ---------- স্ক্রিন থেকে লেখা সংগ্রহ ----------
    private fun collect(node: AccessibilityNodeInfo?, out: MutableSet<String>) {
        if (node == null) return
        if (node.packageName?.toString() == packageName) return
        if (node.isVisibleToUser) {
            val t = node.text?.toString()?.trim()
            val d = node.contentDescription?.toString()?.trim()
            when {
                !t.isNullOrEmpty() -> out.add(t)
                !d.isNullOrEmpty() && node.childCount == 0 -> out.add(d)
            }
        }
        for (i in 0 until node.childCount) collect(node.getChild(i), out)
    }

    // ---------- সিলেকশন প্যানেল ----------
    private fun showPanel(items: List<String>) {
        val checks = items.map { s ->
            CheckBox(this).apply {
                text = s
                setTextColor(Color.WHITE)
                textSize = 15f
                buttonTintList = android.content.res.ColorStateList.valueOf(0xFFBB86FC.toInt())
                setPadding(dp(4), dp(8), dp(4), dp(8))
            }
        }

        fun headerButton(label: String, onClick: () -> Unit) = TextView(this).apply {
            text = label
            setTextColor(Color.WHITE)
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = GradientDrawable().apply {
                cornerRadius = dp(8).toFloat()
                setColor(0xFF6200EE.toInt())
            }
            setOnClickListener { onClick() }
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
            val gap = { LinearLayout.LayoutParams(0, 0).apply { width = dp(8); height = 1 } }

            addView(headerButton("সব") {
                val all = checks.all { it.isChecked }
                checks.forEach { it.isChecked = !all }
            })
            addView(View(context), gap())
            addView(headerButton("কপি") {
                val chosen = checks.filter { it.isChecked }.map { it.text.toString() }
                if (chosen.isEmpty()) {
                    Toast.makeText(context, "আগে লেখা সিলেক্ট করুন", Toast.LENGTH_SHORT).show()
                } else {
                    val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("Universal Copy", chosen.joinToString("\n")))
                    Toast.makeText(context, "কপি হয়েছে (${chosen.size}টি)", Toast.LENGTH_SHORT).show()
                    closePanel()
                }
            })
            addView(View(context), gap())
            addView(headerButton("বন্ধ") { closePanel() })
        }

        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, dp(12), dp(12))
            checks.forEach { addView(it) }
        }
        val scroll = ScrollView(this).apply { addView(list) }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xF2121212.toInt())
            addView(header)
            addView(scroll, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT))
        }

        val h = (resources.displayMetrics.heightPixels * 0.7).toInt()
        val lp = overlayParams(WindowManager.LayoutParams.MATCH_PARENT, h).apply {
            gravity = Gravity.BOTTOM
        }
        wm.addView(root, lp)
        panel = root
    }

    private fun closePanel() {
        panel?.let { runCatching { wm.removeView(it) } }
        panel = null
    }
}
