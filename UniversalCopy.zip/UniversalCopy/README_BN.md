# Universal Copy (Samsung A52 এর জন্য)

## APK বানানোর নিয়ম
1. কম্পিউটারে Android Studio (সর্বশেষ ভার্সন) ইনস্টল করুন।
2. ZIP আনজিপ করুন → Android Studio তে File > Open > UniversalCopy ফোল্ডার।
3. নিচে "Sync" এর জন্য অপেক্ষা করুন (প্রথমবার ইন্টারনেট লাগবে, কয়েক মিনিট)।
4. Build > Build Bundle(s)/APK(s) > Build APK(s)
5. APK ফাইল: app/build/outputs/apk/debug/app-debug.apk → ফোনে পাঠিয়ে ইনস্টল করুন।

## ফোনে চালু করা
1. অ্যাপ খুলে "Accessibility সেটিংস খুলুন" চাপুন।
2. Installed apps → Universal Copy → ON।
3. Samsung এ "Restricted setting" এলে: Settings > Apps > Universal Copy > ৩ ডট > Allow restricted settings।
4. যেকোনো অ্যাপে ভাসমান "কপি" বাটন চাপুন → লেখা টিক দিন → কপি।
